## ProUI-Nxt Introduction
ProUI-Nxt is a keyword driven UI-Automation framework. It is built on top of protractor. Tests can be written using Jasmine or Cucumber. ProUI-Nxt has zero or minimal learning curve
## UI-bl Introduction
UI-bl consists of page objects of different applications with their core functional scenario covered.
## Steps to follow
1.	Clone project: $ git clone https://github.build.ge.com/ToolsEngineering/ProUINxt.git

2.	Install dependencies required using following command

    **npm install**

3.	Transpile the project files using following command
  
    a.	To transpile all the *.ts files mentioned in tsconfig.json use below command

      **tsc**

    b.	To transpile specific ts file (Eg: stepDef.ts) use below command

      **tsc stepDef**

4.	Install Webdriver using the following command

    **grunt test**

For complete ProUI-Nxt documentation please refer to below confluence page :

   **https://devcloud.swcoe.ge.com/devspace/display/KKQTL/ProUI-Nxt**

For complete UI-bl documentation please refer to below confluence page :

   **https://devcloud.swcoe.ge.com/devspace/display/KKQTL/UI-bl**
   
