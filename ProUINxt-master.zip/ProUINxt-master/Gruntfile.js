module.exports = function(grunt) {
    'use strict';


    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),

        jshint: {
            files: ['Gruntfile.js', 'step_definitions/*.js'],
            options: {
                // options here to override JSHint defaults
                globals: {
                    jQuery: true,
                    console: true,
                    module: true,
                    document: true
                }
            }

        },

        execute: {
            target: {
                src:['./node_modules/@ge-tools/ui-nxt/updateChromeDriver.js']
            }
        },

        shell: {
            options: {
                stdout:true
            },
            disableSSL:
            {
                command:'npm config set strict-ssl false'
            },
            npm_install: {
                command: 'npm install --only=dev'// --proxy=http://sjc1intproxy02.crd.ge.com:8080'
            },
            npm_update: {
                command: 'npm update --only=dev'// --proxy=http://sjc1intproxy02.crd.ge.com:8080'
            },
            protractor_install: {
                command: 'node ./node_modules/protractor/bin/webdriver-manager update'// --proxy=http://sjc1intproxy02.crd.ge.com:8080 --ignore_ssl'
            },
            // ie_install: {
            //     command: 'node ./node_modules/protractor/bin/webdriver-manager update --ie --proxy=http://sjc1intproxy02.crd.ge.com:8080'
            // }


        },

        protractor: {
            default: {
            options: {
                keepAlive: false,
                configFile: 'Projects/Sample/Conf/Config.js',
                args: {suite: 'basicTest'}
                },
            },
        
            test: {
                options: {
                    keepAlive: false,
                    configFile: grunt.option('conf') || 'Projects/Sample/Conf/Config.js',
                    args: {suite: grunt.option('suite') || 'basicTest'}
                },
            }, 
         
        browser:{
            options: {
                keepAlive: false,
                configFile: grunt.option('conf'),
                args: {cucumberOpts:grunt.option('spec'),suite: grunt.option('suite'), browser: grunt.option('browser')}
            },
        },

        noSuite: {
                options: {
                    keepAlive: false,
                    configFile: grunt.option('conf'),
                },
            },
            singlerun: {},
            auto: {
                keepAlive: false,
                options: {
                    args: {
                        seleniumPort: 4444
                    }
                }
            }
        },


    });

    var target = grunt.option('target') || 'def';

    grunt.loadNpmTasks('grunt-contrib-jshint');

    grunt.loadNpmTasks('grunt-execute');

    grunt.loadNpmTasks('grunt-contrib-jshint');

    grunt.loadNpmTasks('grunt-shell-spawn');

    grunt.loadNpmTasks('grunt-protractor-runner');

    //grunt.loadNpmTasks('perfjankie');

    grunt.registerTask('default',  function(arg) {
        try {
            grunt.task.run('jshint');
            grunt.task.run('execute:target');
            grunt.task.run('shell');
            grunt.task.run('protractor:default');

        } catch(e) {
            // Something went wrong.
            grunt.verbose.or.write(msg).error().error(e.message);
            grunt.fail.warn('Something went wrong.');
        }
    });

    grunt.registerTask('test',  function(arg) {
        try {
            grunt.task.run('jshint');
            grunt.task.run('execute:target');
            grunt.task.run('shell');
            grunt.task.run('protractor:test');

        } catch(e) {
            // Something went wrong.
            grunt.verbose.or.write(msg).error().error(e.message);
            grunt.fail.warn('Something went wrong.');
        }
    });

    grunt.registerTask('noSuite',  function(arg) {
        try {
            grunt.task.run('jshint');
            grunt.task.run('execute:target');
            grunt.task.run('shell');
            grunt.task.run('protractor:noSuite');

        } catch(e) {
            // Something went wrong.
            grunt.verbose.or.write(msg).error().error(e.message);
            grunt.fail.warn('Something went wrong.');
        }
    });


    grunt.registerTask('browser',  function(arg) {
        try {
            grunt.task.run('jshint');
            grunt.task.run('execute:target');
            grunt.task.run('shell');
            grunt.task.run('protractor:browser');

        } catch(e) {
            // Something went wrong.
            grunt.verbose.or.write(msg).error().error(e.message);
            grunt.fail.warn('Something went wrong.');
        }
    });


    grunt.registerTask('run', ['protractorperf']);
};