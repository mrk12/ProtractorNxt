import {browser, element, by} from 'protractor';

export class HomePage {
    header = element(by.xpath('//h1'));

    //Navigate to home page
    async get(): Promise<void> {
        await browser.get('https://help.github.com/categories/github-pages-basics/');
    }

    // getHeaderText returns a native Promise<string>
    async getHeaderText(): Promise<string> {
        return this.header.getText();
    }
}