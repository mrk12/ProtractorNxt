import {browser, element, by, By, $, $$, ExpectedConditions} from 'protractor';
import {Config} from 'protractor';

export const config: Config = {

    // ---- While testing locally
    SELENIUM_PROMISE_MANAGER: false,
    sauceUser: null,
    sauceKey: null,
    sauceSeleniumAddress: null,
    directConnect: true,
    firefoxPath: null,
    elementTimeWait: 50000,

    specs: [],
    // Patterns to exclude.
    exclude: [],

    //Organize spec files into suites. To run specific suite, --suite=<name of suite>
    suites: {
        basicTest: [
        '../Features/APMSelectFeature.feature',
        '../Features/checkBoxNRadioButtonTest.feature',
        '../Features/siteSelectorFeature.feature',
        ],
    },

    //Before launching the application
    beforeLaunch: function () {
    },
    capabilities: {
        browserName: 'chrome',
        count: 1,
        shardTestFiles: false,
        maxInstances: 1,
        chromeOptions: {
            args: ['--no-sandbox', '--test-type=browser', '--start-maximized', '--incognito'],
            prefs: {
                download: {
                    prompt_for_download: false,
                    directory_upgrade: true,
                    default_directory: 'C:/'
                }
            }
        }
    },

    // Browser parameters for feature files.
    params: {
        environment: 'onprem',
		login: {
			baseUrl: 'http://hydqaapm1.meridium.com/meridium/index.html',
			username: 'bl',
            password: 'bl',
            database: 'V4030100_TEST_MON_AM_SQL14...'
		}
    },

    maxSessions: -1,

    allScriptsTimeout: 250000,

    //How long to wait for a page to load.
    getPageTimeout: 650000,

    //Application is launched but before it starts executing
    onPrepare: function () {
        browser.manage().deleteAllCookies();
        browser.manage().timeouts().pageLoadTimeout(60000);
    },

    // A callback function called once tests are finished
    onComplete: function () {
    },

    // A callback function called once tests are cleaning up
    onCleanUp: function (exitCode) {

    },

    // A callback function after tests are launched
    afterLaunch: function () {

    },
    resultJsonOutputFile: null,

    // If true, protractor will restart the browser between each test.
    // CAUTION: This will cause your tests to slow down drastically.
    restartBrowserBetweenTests: false,
    plugins: [{
        package: 'protractor-multiple-cucumber-html-reporter-plugin',
        options:{
            // read the options part for more options
            automaticallyGenerateReport: true,
            removeExistingJsonReportFile: true
        }
    }],

    // Custom framework in this case cucumber
    framework: 'custom',
    frameworkPath: require.resolve('protractor-cucumber-framework'),
    cucumberOpts: {

        // define your step definitions in this file
        require: [
             '../step_definitions/APMSelectTest.js',
            '../step_definitions/CheckBoxNRadioButtonTest.js',
            '../step_definitions/siteSelectorTest.js',
        ],
        format: 'json:Reports/results.json',
        strict: true

    }
}