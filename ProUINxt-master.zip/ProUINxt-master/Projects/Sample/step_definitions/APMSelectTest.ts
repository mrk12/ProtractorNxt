import { browser, ElementFinder} from 'protractor';
import { CoreUtility } from '@ge-tools/ui-nxt';
import { Given, Then } from 'cucumber'
import { ApmBL, Menus } from '@ge-tools/ui-bl-apm_m';

let CoreUtilityFile = new CoreUtility("Projects/Sample/Locators/sample.json", "APMSelect");

let apmBL = new ApmBL();

Given(/^Open Calibration Profile Page$/,{timeout: 160000},async function () {

browser.ignoreSynchronization = true;

//login and navigate to admin application settings
await apmBL.Login.navigateAndLogin();
await apmBL.Navigation.navigateToScreen(Menus.menu.admin, Menus.subMenu.adminApplicationSettings);

//click on clibration management link
await CoreUtilityFile.Action.click("lnkCalibManagement");
await CoreUtilityFile.Action.click("lnkStrategies");
await CoreUtilityFile.Action.click("btnStrategy");

});
Then(/^Verify CalibrationType dropdown is not empty and is enabled$/, {timeout: 160000}, async function () {
    const apmTemplateType : ElementFinder = await CoreUtilityFile.Element.getElement("apmTemplateType");
    
    const isCalibDropDwnEnabled : boolean = await apmTemplateType.isEnabled()
    if(isCalibDropDwnEnabled)
    console.log("CalibrationType dropdown is not enabled");
    
});
Then(/^Open and close and Verify CalibrationType dropdown$/, {timeout: 160000}, async function () {

    //Set select drop down webElement
    const apmTemplateType : ElementFinder = await CoreUtilityFile.Element.getElement("apmTemplateType");
    apmBL.CustomAPMSelectWrapper.webElement = apmTemplateType;

    //Open Template Type drop down
    await apmBL.CustomAPMSelectWrapper.deselectAll();
    const isTemplateTypeDrpDwnOpen : boolean = await apmBL.CustomAPMSelectWrapper.open();
    if(isTemplateTypeDrpDwnOpen){
        console.log('Template type drop down is opened')
    }
    
    //Close Template Type drop down
    const isTemplateTypeDrpDwnClosed = await apmBL.CustomAPMSelectWrapper.close();
    if(isTemplateTypeDrpDwnClosed){
        console.log('Template type drop down is closed')
    }
   
});

Then(/^Verify all items count and all options text$/, {timeout: 160000}, async function () {
  
    //Get count of Template Type drop down options
    const count = await apmBL.CustomAPMSelectWrapper.getAllCount();
    console.log('Template Type drop down options count :'+count);

    //Get text of all options available in Template Type drop down
    const list : string[]= await apmBL.CustomAPMSelectWrapper.getAllOptionsText();
        for (var i = 0; i < list.length; i++) {
           console.log('option text' +list[i]);
        }
     });

Then(/^Select by Text, Verify all selected count and Selected Option Text$/, async function () {
    
    //Select Template Type drop down by text
    const isSelectedByText : boolean = await apmBL.CustomAPMSelectWrapper.selectByText('WeightScale Calibration');
    if(isSelectedByText){
     //Get count of selected options in calibration drop down   
    const selectedCount = await apmBL.CustomAPMSelectWrapper.getAllSelectedCount()
        console.log('selected Count of elements : ' +selectedCount);

        //Get selected text from Template Type drop down
        await apmBL.CustomAPMSelectWrapper.getSelectedOptionText();
    }

});
Then(/^Get All Selected Option Text$/, async function () {
   
    //Get all selected options text from Template Type drop down
    const allSelectedOptionsText : string[] = await apmBL.CustomAPMSelectWrapper.getAllSelectedOptionsText();
    for(let i=0;i<allSelectedOptionsText.length;i++){
        console.log(`select option text : ${allSelectedOptionsText[i]}`);
    }       
})
Then(/^Select by Partial Text and by Index$/, {timeout: 160000},async function () {
    
    //Select Template Type drop down by partial text
    await apmBL.CustomAPMSelectWrapper.selectByPartialText('Analog Calibration');

    await apmBL.CustomAPMSelectWrapper.selectByIndex(4);
    await browser.sleep(5000);
});