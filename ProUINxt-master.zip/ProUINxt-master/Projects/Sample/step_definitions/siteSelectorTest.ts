import { browser, ElementFinder } from 'protractor';
import { CoreUtility } from '@ge-tools/ui-nxt';
import { Given, Then } from 'cucumber'
import { ApmBL, Menus } from '@ge-tools/ui-bl-apm_m';

let CoreUtilityFile = new CoreUtility( "Projects/Sample/Locators/sample.json", "SiteSelector");

var elementDetails = {
    locatorType: 'xpath',
    locatorValue: '(//mi-site-selector)[1]'
};
let apmBL = new ApmBL();
//Set the site locator
apmBL.SiteSelector.Locator = elementDetails;


Given('Open SIL Analysis Page', {timeout: 160000}, async function () {
    browser.ignoreSynchronization = true;

    await apmBL.Login.navigateAndLogin();
    await apmBL.Navigation.navigateToScreen(Menus.menu.integrity, Menus.subMenu.integrityHazardsAnalysis);

    let tabHazopElement: ElementFinder = await CoreUtilityFile.Element.getElement("tabHazop");
    //click on sil ananlyis tab
    await browser.executeScript("arguments[0].click()", tabHazopElement);

    //wait for the gird to load
    await CoreUtilityFile.Assertion.isElementDisplayed('gridRecords');

    //click on new sil analysis plus icon
    await CoreUtilityFile.Action.click("newAnalysis");


});

Then('Verify Site Selector is Enabled', {timeout: 160000}, async function () {
    let bStatus: boolean = await apmBL.SiteSelector.isSiteSelectorEnabled();
    if (bStatus) {
        console.log("Verified Site Selector is not enabled ");
    }

});

Then('Select site by Text, Partial Text and Index and get the count', {timeout: 160000}, async function () {

    const partialSiteText = "Alexanderson";
    const fullSiteText = "Covington";

    //Select site by index
    const isSiteSelectedByIndex: boolean = await apmBL.SiteSelector.selectSiteByIndex(3);
    if (isSiteSelectedByIndex) {
        console.log("Site selected by index");
    }

    //Select site by text
    const isSiteSelected: boolean = await apmBL.SiteSelector.selectSiteByText(fullSiteText);
    if (isSiteSelected) {
        console.log("Site selected by actual text");
    }

    //Select site by partial text
    const isSiteSelectedByPartialText: boolean = await apmBL.SiteSelector.selectSiteByPartialText(partialSiteText);
    if (isSiteSelectedByPartialText) {
        console.log("Site selected by partial text");
    }

    //Get test of selected site
    const siteName = await apmBL.SiteSelector.getSelectedSiteText();
    if (siteName !== null) {
        console.log('selected site is : ' + siteName);
    }

    //Get count of sites
    const siteCount = await apmBL.SiteSelector.getAllSitesCount();
    if (siteCount !== 0) {
        console.log("count of sites is : " + siteCount);
    }

});
