
import { CoreUtility, locatorDetails } from '@ge-tools/ui-nxt';
import { browser} from 'protractor';

const { Given, Then } = require('cucumber');
let CoreUtilityfile = new CoreUtility();

Given('navigate to url for testing check box functionality {string}', { timeout: 30000 }, async (url: string) => {

  browser.ignoreSynchronization = true;
  await browser.get(url);
 
});
Then('check box checked or unchecked', { timeout: 30000 }, async () => {
  let checkBoxElement: locatorDetails = {
    locatorType: "xpath",
    locatorValue: "//div[@class='checkbox']//input[@id='isAgeSelected']"
  };

  //Check whether check box element is not selected
  await CoreUtilityfile.Assertion.assertCheckBoxNotSelected(checkBoxElement);

  //select the check box element
  await CoreUtilityfile.Action.click(checkBoxElement);

  //Check whether check box element is selected
  await CoreUtilityfile.Assertion.assertCheckBoxSelected(checkBoxElement);

  //Negative Scenario : checking checkbox not selected on check box element,which will throw an error
  await CoreUtilityfile.Assertion.assertCheckBoxNotSelected(checkBoxElement).catch((error: any) => {
    console.log(error.name);
});

});

Given('navigate to url for testing radio button functionality {string}', { timeout: 30000 }, async (url: string) => {
    
    await browser.get(url);

});

Then('check radio button is selected or not', { timeout: 30000 }, async () => {

  
    let radioButtonElement: locatorDetails = {
        locatorType: "xpath",
        locatorValue: "//div[text()='Radio Button Demo']/following-sibling::div//input[@type='radio' and @value='Male']"
      };
      //Check whether radio button element is not selected
      await CoreUtilityfile.Assertion.assertRadioButtonNotSelected(radioButtonElement);
      
      //select the radio button element
      await CoreUtilityfile.Action.click(radioButtonElement);
      //Check whether radio button element is selected
      await CoreUtilityfile.Assertion.assertRadioButtonSelected(radioButtonElement);

      //Negative Scenario : check radio button not selected on radio button selected element,which will throw an error
      await CoreUtilityfile.Assertion.assertRadioButtonNotSelected(radioButtonElement).catch((error: any) => {
        console.log(error.name);
    });

});




